/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}"],
  theme: {
    extend: {
      colors: {
        navy: "#1a365d",
        purple: "#6b21a8",
        gold: "#c9a84c",
      },
    },
  },
  plugins: [],
};
